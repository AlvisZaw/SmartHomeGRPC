package com.smarthome.server;

import io.grpc.*;

public class AuthInterceptor implements ServerInterceptor {
    @Override
    public <ReqT, RespT> ServerCall.Listener<ReqT> interceptCall(
            ServerCall<ReqT, RespT> call, Metadata headers,
            ServerCallHandler<ReqT, RespT> next) {

        String apiKey = headers.get(Metadata.Key.of("api-key", Metadata.ASCII_STRING_MARSHALLER));

        if (!"my-secret-key".equals(apiKey)) {
            call.close(Status.UNAUTHENTICATED.withDescription("Invalid API Key"), headers);
            return new ServerCall.Listener<ReqT>() {};
        }

        return next.startCall(call, headers);
    }
}
