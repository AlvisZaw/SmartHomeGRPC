package com.smarthome.server;

import com.smarthome.generated.connecteddevices.*;

import io.grpc.stub.StreamObserver;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConnectedDevicesServiceImpl extends ConnectedDevicesGrpc.ConnectedDevicesImplBase {

    // Maps to store registered devices and their statuses
    private final Map<String, String> deviceStatusMap = new ConcurrentHashMap<>();
    private final Map<String, String> registeredDevices = new ConcurrentHashMap<>();

    @Override
    public void controlDevice(DeviceRequest request, StreamObserver<DeviceResponse> responseObserver) {
        String deviceId = request.getDeviceId();
        String action = request.getAction();

        // Check if the device is registered
        if (!registeredDevices.containsKey(deviceId)) {
            DeviceResponse response = DeviceResponse.newBuilder()
                    .setStatus("Unauthenticated: Invalid API Key or Unregistered Device")
                    .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        System.out.printf("Received control request: device_id=%s, action=%s%n", deviceId, action);

        String statusMessage;
        if ("on".equalsIgnoreCase(action) || "off".equalsIgnoreCase(action)) {
            deviceStatusMap.put(deviceId, action.toLowerCase());
            statusMessage = "Device " + deviceId + " turned " + action;
        } else {
            statusMessage = "Unknown action: " + action;
        }

        DeviceResponse response = DeviceResponse.newBuilder()
                .setStatus(statusMessage)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getDeviceStatus(DeviceStatusRequest request, StreamObserver<DeviceStatusResponse> responseObserver) {
        String deviceId = request.getDeviceId();

        // Check if the device is registered
        if (!registeredDevices.containsKey(deviceId)) {
            DeviceStatusResponse response = DeviceStatusResponse.newBuilder()
                    .setStatus("Unauthenticated: Invalid API Key or Unregistered Device")
                    .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        // Simulate fetching status
        String status = deviceStatusMap.getOrDefault(deviceId, "unknown");

        System.out.printf("Status request for device %s: %s%n", deviceId, status);

        DeviceStatusResponse response = DeviceStatusResponse.newBuilder()
                .setStatus(status)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    // Device Registration
    @Override
    public void registerDevice(RegisterRequest request, StreamObserver<RegisterResponse> responseObserver) {
        String deviceId = request.getDeviceId();
        String deviceType = request.getDeviceType();

        // Register the device
        registeredDevices.put(deviceId, deviceType);

        String msg = "Device " + deviceId + " of type " + deviceType + " registered successfully.";
        System.out.println(msg);

        RegisterResponse response = RegisterResponse.newBuilder()
                .setMessage(msg)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    // Device Discovery
    @Override
    public void listDevices(Empty request, StreamObserver<DeviceList> responseObserver) {
        DeviceList.Builder listBuilder = DeviceList.newBuilder();

        for (Map.Entry<String, String> entry : registeredDevices.entrySet()) {
            DeviceInfo deviceInfo = DeviceInfo.newBuilder()
                    .setDeviceId(entry.getKey())
                    .setDeviceType(entry.getValue())
                    .build();

            listBuilder.addDevices(deviceInfo);
        }

        responseObserver.onNext(listBuilder.build());
        responseObserver.onCompleted();
    }
}
