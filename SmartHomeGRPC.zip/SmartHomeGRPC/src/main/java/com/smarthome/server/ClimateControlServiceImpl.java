package com.smarthome.server;

import generated.climate.control.*;
import io.grpc.stub.StreamObserver;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ClimateControlServiceImpl extends ClimateControlGrpc.ClimateControlImplBase {

    private final Map<String, String> deviceStatusMap = new ConcurrentHashMap<>();

    @Override
    public void controlDevice(DeviceRequest request, StreamObserver<DeviceResponse> responseObserver) {
        String deviceId = request.getDeviceId();
        String action = request.getAction();

        String status = "Device " + deviceId + " performed action: " + action;
        deviceStatusMap.put(deviceId, action);

        DeviceResponse response = DeviceResponse.newBuilder().setStatus(status).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getDeviceStatus(DeviceStatusRequest request, StreamObserver<DeviceStatusResponse> responseObserver) {
        String deviceId = request.getDeviceId();
        String status = deviceStatusMap.getOrDefault(deviceId, "unknown");

        DeviceStatusResponse response = DeviceStatusResponse.newBuilder().setStatus(status).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void monitorDeviceStatus(DeviceStatusRequest request, StreamObserver<DeviceStatusResponse> responseObserver) {
        String deviceId = request.getDeviceId();

        // Simulate periodic status updates (for example purposes only)
        for (int i = 0; i < 5; i++) {
            String status = deviceStatusMap.getOrDefault(deviceId, "unknown") + " (update " + (i+1) + ")";
            DeviceStatusResponse response = DeviceStatusResponse.newBuilder().setStatus(status).build();
            responseObserver.onNext(response);

            try {
                Thread.sleep(1000); // Simulate delay
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        responseObserver.onCompleted();
    }

    @Override
    public StreamObserver<DeviceRequest> controlMultipleDevices(StreamObserver<DeviceResponse> responseObserver) {
        return new StreamObserver<DeviceRequest>() {
            StringBuilder results = new StringBuilder();

            @Override
            public void onNext(DeviceRequest request) {
                String deviceId = request.getDeviceId();
                String action = request.getAction();
                deviceStatusMap.put(deviceId, action);
                results.append("Device ").append(deviceId).append(" performed action: ").append(action).append("\n");
            }

            @Override
            public void onError(Throwable t) {
                t.printStackTrace();
            }

            @Override
            public void onCompleted() {
                DeviceResponse response = DeviceResponse.newBuilder().setStatus(results.toString()).build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }
        };
    }

    @Override
    public StreamObserver<DeviceRequest> interactWithDevices(StreamObserver<DeviceStatusResponse> responseObserver) {
        return new StreamObserver<DeviceRequest>() {
            @Override
            public void onNext(DeviceRequest request) {
                String deviceId = request.getDeviceId();
                String action = request.getAction();
                deviceStatusMap.put(deviceId, action);

                String status = "Device " + deviceId + " now " + action;
                DeviceStatusResponse response = DeviceStatusResponse.newBuilder().setStatus(status).build();
                responseObserver.onNext(response);
            }

            @Override
            public void onError(Throwable t) {
                t.printStackTrace();
            }

            @Override
            public void onCompleted() {
                responseObserver.onCompleted();
            }
        };
    }
}
