package com.smarthome.server;

import com.smarthome.server.AuthInterceptor; 
import com.smarthome.server.SmartSecurityServiceImpl; //Import the smart security service
import com.smarthome.server.ConnectedDevicesServiceImpl; //Import the connected devices service
import com.smarthome.server.ClimateControlServiceImpl; // Import the new service

import io.grpc.Server;
import io.grpc.ServerBuilder;

public class SmartHomeServer {
    public static void main(String[] args) throws Exception {
        Server server = ServerBuilder.forPort(9090)
            .addService(new SmartSecurityServiceImpl())
            .addService(new ConnectedDevicesServiceImpl())
            .addService(new ClimateControlServiceImpl()) //  Register ClimateControl
            .intercept(new AuthInterceptor()) // <-- Register AuthInterceptor
            .build();

        System.out.println("gRPC Server started on port 9090...");
        server.start();
        server.awaitTermination();
    }
}
