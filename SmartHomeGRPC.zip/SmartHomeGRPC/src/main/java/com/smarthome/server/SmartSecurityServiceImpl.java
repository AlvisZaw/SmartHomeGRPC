package com.smarthome.server;

import generated.smart.security.SmartSecurityGrpc;
import generated.smart.security.*;

import io.grpc.stub.StreamObserver;

public class SmartSecurityServiceImpl extends SmartSecurityGrpc.SmartSecurityImplBase {

    // Unary - Get the live video feed URL for a specific camera
    @Override
    public void getLiveFeed(CameraRequest request, StreamObserver<CameraResponse> responseObserver) {
        String cameraId = request.getCameraId();

        CameraResponse response = CameraResponse.newBuilder()
            .setVideoStreamUrl("http://example.com/stream/" + cameraId)
            .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    // Unary - Lock or unlock a specific door
    @Override
    public void lockDoor(DoorRequest request, StreamObserver<DoorResponse> responseObserver) {
        String doorId = request.getDoorId();
        boolean lock = request.getLock();

        String status = lock ? "Locked door " + doorId : "Unlocked door " + doorId;

        DoorResponse response = DoorResponse.newBuilder()
            .setStatus(status)
            .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    // Server Streaming - Monitor motion detection
    @Override
    public void monitorMotion(MotionRequest request, StreamObserver<MotionResponse> responseObserver) {
        String sensorId = request.getSensorId();

        // Simulate 3 fake motion alerts
        for (int i = 1; i <= 3; i++) {
            MotionResponse response = MotionResponse.newBuilder()
                .setMotionDetected(i % 2 == 0)
                .setAlertMessage("Motion detected by sensor " + sensorId + " - Alert #" + i)
                .build();

            responseObserver.onNext(response);

            try {
                Thread.sleep(1000); // simulate delay
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        responseObserver.onCompleted();
    }

    // Bidirectional Streaming - Control multiple doors
    @Override
    public StreamObserver<DoorRequest> controlDoors(final StreamObserver<DoorResponse> responseObserver) {
        return new StreamObserver<DoorRequest>() {
            @Override
            public void onNext(DoorRequest request) {
                String doorId = request.getDoorId();
                boolean lock = request.getLock();
                String status = lock ? "Locked door " + doorId : "Unlocked door " + doorId;

                DoorResponse response = DoorResponse.newBuilder()
                    .setStatus(status)
                    .build();

                responseObserver.onNext(response);
            }

            @Override
            public void onError(Throwable t) {
                System.err.println("Error in controlDoors: " + t.getMessage());
            }

            @Override
            public void onCompleted() {
                responseObserver.onCompleted();
            }
        };
    }
}
