package com.smarthome.client;

import com.smarthome.generated.connecteddevices.DeviceRequest;
import com.smarthome.generated.connecteddevices.DeviceResponse;
import com.smarthome.generated.connecteddevices.ConnectedDevicesGrpc;
import com.smarthome.generated.connecteddevices.DeviceStatusRequest;
import com.smarthome.generated.connecteddevices.DeviceStatusResponse;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class SmartHomeClientGUI extends JFrame {
    
    private JTextField deviceIdField;
    private JTextArea statusArea;
    private JButton onButton;
    private JButton offButton;
    private JButton getStatusButton;

    public SmartHomeClientGUI() {
        setTitle("Smart Home Control");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Set up the layout
        setLayout(new BorderLayout());

        // Device ID field and status area
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        JLabel deviceIdLabel = new JLabel("Device ID: ");
        deviceIdField = new JTextField(20);
        panel.add(deviceIdLabel);
        panel.add(deviceIdField);

        JLabel statusLabel = new JLabel("Device Status: ");
        statusArea = new JTextArea(5, 20);
        statusArea.setEditable(false);
        panel.add(statusLabel);
        panel.add(new JScrollPane(statusArea));

        // Control buttons
        onButton = new JButton("Turn On");
        offButton = new JButton("Turn Off");
        getStatusButton = new JButton("Get Status");

        panel.add(onButton);
        panel.add(offButton);
        panel.add(getStatusButton);

        add(panel, BorderLayout.CENTER);

        // Button actions
        onButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendControlRequest("on");
            }
        });

        offButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendControlRequest("off");
            }
        });

        getStatusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getDeviceStatus();
            }
        });
    }

    private void sendControlRequest(String action) {
        String deviceId = deviceIdField.getText().trim();
        if (deviceId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Device ID", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Create a channel to the server
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9090)
                .usePlaintext()
                .build();

        // Stub to send request
        ConnectedDevicesGrpc.ConnectedDevicesBlockingStub blockingStub = ConnectedDevicesGrpc.newBlockingStub(channel);

        // Send control request
        DeviceRequest request = DeviceRequest.newBuilder()
                .setDeviceId(deviceId)
                .setAction(action)
                .build();

        try {
            DeviceResponse response = blockingStub.controlDevice(request);
            statusArea.setText(response.getStatus());
        } catch (Exception e) {
            statusArea.setText("Error: " + e.getMessage());
        }

        channel.shutdown();
    }

    private void getDeviceStatus() {
        String deviceId = deviceIdField.getText().trim();
        if (deviceId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Device ID", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Create a channel to the server
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9090)
                .usePlaintext()
                .build();

        // Stub to get status
        ConnectedDevicesGrpc.ConnectedDevicesBlockingStub blockingStub = ConnectedDevicesGrpc.newBlockingStub(channel);

        // Request status
        try {
            DeviceStatusRequest request = DeviceStatusRequest.newBuilder()
                    .setDeviceId(deviceId)
                    .build();

            DeviceStatusResponse response = blockingStub.getDeviceStatus(request);
            statusArea.setText(response.getStatus());
        } catch (Exception e) {
            statusArea.setText("Error: " + e.getMessage());
        }

        channel.shutdown();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SmartHomeClientGUI().setVisible(true);
            }
        });
    }
}
