package com.smarthome.client;

import generated.smart.security.*;

import io.grpc.*;
import io.grpc.stub.MetadataUtils;

public class SmartHomeClient {

    public static void main(String[] args) {
        // API Key to be sent in the header
        Metadata metadata = new Metadata();
        Metadata.Key<String> apiKeyHeader = Metadata.Key.of("api-key", Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(apiKeyHeader, "my-secret-key");  // Change this to something else to test failure

        // Create channel and stub
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9090)
                .usePlaintext()
                .build();

        // Attach metadata (headers)
        SmartSecurityGrpc.SmartSecurityBlockingStub blockingStub = SmartSecurityGrpc
                .newBlockingStub(channel)
                .withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));

        // Prepare request
        CameraRequest request = CameraRequest.newBuilder()
                .setCameraId("CAM001")
                .build();

        try {
            CameraResponse response = blockingStub.getLiveFeed(request);
            System.out.println("Received video stream URL: " + response.getVideoStreamUrl());
        } catch (StatusRuntimeException e) {
            System.err.println("RPC failed: " + e.getStatus());
        } finally {
            channel.shutdown();
        }
    }
}
