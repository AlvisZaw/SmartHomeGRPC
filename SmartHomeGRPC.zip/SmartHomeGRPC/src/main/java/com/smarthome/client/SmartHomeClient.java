package com.smarthome.client;

import generated.smart.security.*;
import generated.climate.control.*;
import io.grpc.*;
import io.grpc.stub.MetadataUtils;

public class SmartHomeClient {

    public static void main(String[] args) {
        // API Key to be sent in the header
        Metadata metadata = new Metadata();
        Metadata.Key<String> apiKeyHeader = Metadata.Key.of("api-key", Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(apiKeyHeader, "my-secret-key");

        // Create channel and attach header
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9090)
                .usePlaintext()
                .build();

        // Security Service
        SmartSecurityGrpc.SmartSecurityBlockingStub securityStub = SmartSecurityGrpc
                .newBlockingStub(channel)
                .withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));

        // Connected Devices Service
        com.smarthome.generated.connecteddevices.ConnectedDevicesGrpc.ConnectedDevicesBlockingStub deviceStub =
                com.smarthome.generated.connecteddevices.ConnectedDevicesGrpc
                        .newBlockingStub(channel)
                        .withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));

        // Climate Control Service
        ClimateControlGrpc.ClimateControlBlockingStub climateStub =
                ClimateControlGrpc.newBlockingStub(channel)
                        .withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));

        try {
            // --- Smart Security ---
            CameraRequest camRequest = CameraRequest.newBuilder()
                    .setCameraId("CAM001")
                    .build();

            CameraResponse camResponse = securityStub.getLiveFeed(camRequest);
            System.out.println("[Security] Video stream URL: " + camResponse.getVideoStreamUrl());

            // --- Connected Devices Example ---
            com.smarthome.generated.connecteddevices.DeviceRequest controlRequest =
                    com.smarthome.generated.connecteddevices.DeviceRequest.newBuilder()
                            .setDeviceId("LIGHT001")
                            .setAction("on")
                            .build();

            com.smarthome.generated.connecteddevices.DeviceResponse controlResponse =
                    deviceStub.controlDevice(controlRequest);
            System.out.println("[Devices] Control response: " + controlResponse.getStatus());

            com.smarthome.generated.connecteddevices.DeviceStatusRequest statusRequest =
                    com.smarthome.generated.connecteddevices.DeviceStatusRequest.newBuilder()
                            .setDeviceId("LIGHT001")
                            .build();

            com.smarthome.generated.connecteddevices.DeviceStatusResponse statusResponse =
                    deviceStub.getDeviceStatus(statusRequest);
            System.out.println("[Devices] Status: " + statusResponse.getStatus());

            // --- Climate Control Example ---
            DeviceRequest climateRequest = DeviceRequest.newBuilder()
                    .setDeviceId("AC001")
                    .setAction("cooling_on")
                    .build();

            DeviceResponse climateResponse = climateStub.controlDevice(climateRequest);
            System.out.println("[Climate] Control response: " + climateResponse.getStatus());

            DeviceStatusRequest climateStatusRequest = DeviceStatusRequest.newBuilder()
                    .setDeviceId("AC001")
                    .build();

            DeviceStatusResponse climateStatusResponse = climateStub.getDeviceStatus(climateStatusRequest);
            System.out.println("[Climate] Status: " + climateStatusResponse.getStatus());

        } catch (StatusRuntimeException e) {
            System.err.println("RPC failed: " + e.getStatus());
        } finally {
            channel.shutdown();
        }
    }
}
